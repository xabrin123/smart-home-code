#分析不同设备的使用频率和使用时间段
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
devices = pd.read_csv(r"E:\数据库\期末项目\数据\device.csv")
device_usages = pd.read_csv(r"E:\数据库\期末项目\数据\device_usage.csv")

# 合并设备信息和使用记录
merged_data = pd.merge(device_usages, devices, left_on='device_id', right_on='id')

# 转换时间列为datetime类型
merged_data['start_time'] = pd.to_datetime(merged_data['start_time'])
merged_data['end_time'] = pd.to_datetime(merged_data['end_time'])

# 1. 分析不同设备类型的使用频率
usage_freq = merged_data['type'].value_counts().sort_values(ascending=False)

print("各设备类型使用频率:")
print(usage_freq)

# 可视化使用频率
plt.figure(figsize=(12, 6))
usage_freq.plot(kind='bar')
plt.title('不同设备类型的使用频率')
plt.xlabel('设备类型')
plt.ylabel('使用次数')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 2. 分析设备使用时间段
# 提取使用开始时间的小时
merged_data['hour'] = merged_data['start_time'].dt.hour

# 按设备类型和小时分组统计
hourly_usage = merged_data.groupby(['type', 'hour']).size().unstack().fillna(0)

# 可视化每个设备类型的使用时间段
plt.figure(figsize=(14, 8))
for i, device_type in enumerate(hourly_usage.index):
    plt.subplot(3, 3, i+1)
    hourly_usage.loc[device_type].plot(kind='bar')
    plt.title(f'{device_type}使用时间段')
    plt.xlabel('小时')
    plt.ylabel('使用次数')
    plt.ylim(0, hourly_usage.max().max())
plt.tight_layout()
plt.show()

# 3. 分析设备平均使用时长
avg_duration = merged_data.groupby('type')['duration'].mean().sort_values(ascending=False)

print("\n各设备类型平均使用时长(秒):")
print(avg_duration)

# 可视化平均使用时长
plt.figure(figsize=(12, 6))
avg_duration.plot(kind='bar')
plt.title('不同设备类型的平均使用时长')
plt.xlabel('设备类型')
plt.ylabel('平均使用时长(秒)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 4. 按房间分析设备使用情况
room_usage = merged_data.groupby('room')['device_id'].count().sort_values(ascending=False)

print("\n各房间设备使用次数:")
print(room_usage)

# 可视化房间使用情况
plt.figure(figsize=(10, 6))
room_usage.plot(kind='bar')
plt.title('各房间设备使用次数')
plt.xlabel('房间')
plt.ylabel('使用次数')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
