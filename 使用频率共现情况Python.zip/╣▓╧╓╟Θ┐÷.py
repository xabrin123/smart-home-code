#共现情况
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
devices = pd.read_csv(r"E:\数据库\期末项目\数据\device.csv")
device_co_occurrence = pd.read_csv(r"E:\数据库\期末项目\数据\device_co_occurrence_.csv")

# 1. 合并设备名称信息
# 为device1添加名称和类型
device_co_occurrence = pd.merge(device_co_occurrence,
                               devices[['id', 'name', 'type']],
                               left_on='device1_id',
                               right_on='id',
                               how='left',
                               suffixes=('', '_device1'))
device_co_occurrence = device_co_occurrence.rename(columns={
    'name': 'device1_name',
    'type': 'device1_type'
})

# 删除可能重复的列（如果有）
device_co_occurrence = device_co_occurrence.loc[:, ~device_co_occurrence.columns.duplicated()]

# 为device2添加名称和类型
device_co_occurrence = pd.merge(device_co_occurrence,
                               devices[['id', 'name', 'type']],
                               left_on='device2_id',
                               right_on='id',
                               how='left',
                               suffixes=('', '_device2'))
device_co_occurrence = device_co_occurrence.rename(columns={
    'name': 'device2_name',
    'type': 'device2_type'
})

# 删除多余的id列（如果存在）
if 'id_device1' in device_co_occurrence.columns:
    device_co_occurrence = device_co_occurrence.drop(columns=['id_device1'])
if 'id_device2' in device_co_occurrence.columns:
    device_co_occurrence = device_co_occurrence.drop(columns=['id_device2'])

# 2. 分析最常见的设备共现组合
top_co_occurrences = device_co_occurrence.sort_values('occurrence_count', ascending=False)

print("最常见的设备共现组合:")
print(top_co_occurrences[['device1_name', 'device1_type',
                         'device2_name', 'device2_type',
                         'occurrence_count', 'last_occurred']].head(10))

# 3. 按设备类型分析共现模式
# 创建设备类型共现矩阵
type_co_occurrence = device_co_occurrence.groupby(['device1_type', 'device2_type'])['occurrence_count'].sum().unstack().fillna(0)

print("\n设备类型共现矩阵:")
print(type_co_occurrence)

# 可视化类型共现矩阵
plt.figure(figsize=(10, 8))
plt.imshow(type_co_occurrence, cmap='YlOrRd')
plt.colorbar(label='共现次数')
plt.xticks(range(len(type_co_occurrence.columns)), type_co_occurrence.columns, rotation=45)
plt.yticks(range(len(type_co_occurrence.index)), type_co_occurrence.index)
plt.title('设备类型共现热力图')
plt.tight_layout()
plt.show()

# 4. 创建设备共现网络图
G = nx.Graph()

# 添加节点和边
for _, row in device_co_occurrence.iterrows():
    G.add_node(row['device1_id'], name=row['device1_name'], type=row['device1_type'])
    G.add_node(row['device2_id'], name=row['device2_name'], type=row['device2_type'])
    G.add_edge(row['device1_id'], row['device2_id'], weight=row['occurrence_count'])

# 绘制网络图
plt.figure(figsize=(12, 10))
pos = nx.spring_layout(G, seed=42)  # 使用固定种子保证布局一致

# 按设备类型着色
node_colors = []
for node in G.nodes():
    node_type = G.nodes[node]['type']
    # 为不同类型分配不同颜色
    if node_type == 'light':
        node_colors.append('yellow')
    elif node_type == 'thermostat':
        node_colors.append('blue')
    elif node_type == 'door_lock':
        node_colors.append('green')
    elif node_type == 'air_conditioner':
        node_colors.append('red')
    elif node_type == 'security_camera':
        node_colors.append('purple')
    elif node_type == 'smart_plug':
        node_colors.append('orange')
    elif node_type == 'motion_sensor':
        node_colors.append('cyan')
    elif node_type == 'window_sensor':
        node_colors.append('pink')
    else:
        node_colors.append('gray')

# 绘制节点和边
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=800)
nx.draw_networkx_edges(G, pos, width=[d['weight']*0.5 for _, _, d in G.edges(data=True)], edge_color='gray')

# 添加标签
node_labels = {node: G.nodes[node]['name'] for node in G.nodes()}
nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=8)

# 添加图例
legend_elements = [
    plt.Line2D([0], [0], marker='o', color='w', label='Light', markerfacecolor='yellow', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Thermostat', markerfacecolor='blue', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Door Lock', markerfacecolor='green', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Air Conditioner', markerfacecolor='red', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Security Camera', markerfacecolor='purple', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Smart Plug', markerfacecolor='orange', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Motion Sensor', markerfacecolor='cyan', markersize=10),
    plt.Line2D([0], [0], marker='o', color='w', label='Window Sensor', markerfacecolor='pink', markersize=10)
]

plt.legend(handles=legend_elements, loc='best')
plt.title('设备共现网络图(边粗细表示共现频率)')
plt.axis('off')
plt.tight_layout()
plt.show()

# 5. 分析每个用户的设备共现模式
user_co_occurrence = device_co_occurrence.groupby('user_id')['occurrence_count'].sum().sort_values(ascending=False)

print("\n用户设备共现频率排名:")
print(user_co_occurrence)
