import matplotlib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 解决中文乱码
matplotlib.rcParams['axes.unicode_minus'] = False    # 解决负号显示为方块


def analyze_house_size_grouped(save_path="static/house_size_grouped_analysis.png"):
    # 1. 加载数据
    users = pd.read_json("data/users.json")
    devices = pd.read_json("data/devices.txt")
    usages = pd.read_json("data/device_usages.txt")

    # 2. 房屋面积分组（避免类别为0的问题）
    bins = [0, 80, 120, 180, 500]
    labels = ['小户型', '中小户型', '中大户型', '大户型']
    users["size_category"] = pd.cut(users["house_size"], bins=bins, labels=labels)

    # 3. 每位用户的设备数量
    device_counts = devices.groupby("user_id").size().reset_index(name="device_count")

    # 4. 映射设备 -> 用户
    device_user_map = devices[["id", "user_id"]].rename(columns={"id": "device_id"})
    usages = usages.merge(device_user_map, on="device_id", how="left")

    # 5. 聚合每位用户的总时长和总能耗
    usage_stats = usages.groupby("user_id").agg({
        "duration": "sum",
        "energy_consumption": "sum"
    }).reset_index().rename(columns={
        "duration": "total_duration",
        "energy_consumption": "total_energy"
    })

    # 6. 合并：用户基础 + 设备数 + 使用行为
    df = users.merge(device_counts, left_on="id", right_on="user_id", how="left")
    df = df.merge(usage_stats, left_on="id", right_on="user_id", how="left")
    df["size_category"] = df["size_category"].cat.remove_unused_categories()
    # ✅ 不修改 size_category，只对数值列填充缺失
    for col in ["device_count", "total_duration", "total_energy"]:
        df[col] = df[col].fillna(0)

    # ✅ 输出各等级人数统计
    print("户型等级分布：\n", df["size_category"].value_counts())

    # 7. 分组计算均值（避免小组数量为 0）
    grouped = df.groupby("size_category")[["device_count", "total_duration", "total_energy"]].mean().reset_index()
    # ✅ 删除 NaN 或没有统计值的户型分组（如“大户型”没有样本）
    grouped = grouped.dropna(subset=["device_count", "total_duration", "total_energy"], how='all')

    print("将用于绘图的分组数据：\n", grouped)

    # 8. 可视化
    plt.figure(figsize=(15, 5))
    sns.set_style("whitegrid")

    matplotlib.rcParams['font.sans-serif'] = ['SimHei']
    matplotlib.rcParams['axes.unicode_minus'] = False

    plt.subplot(1, 3, 1)
    sns.barplot(data=grouped, x="size_category", y="device_count", palette="Blues")
    plt.title("不同户型的平均设备数量")
    plt.ylabel("设备数")

    plt.subplot(1, 3, 2)
    sns.barplot(data=grouped, x="size_category", y="total_duration", palette="Greens")
    plt.title("不同户型的设备使用总时长")
    plt.ylabel("秒")

    plt.subplot(1, 3, 3)
    sns.barplot(data=grouped, x="size_category", y="total_energy", palette="Oranges")
    plt.title("不同户型的设备总能耗")
    plt.ylabel("千瓦时")

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()

    return save_path