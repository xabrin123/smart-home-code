import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

def plot_device_type_room_usage(devices_df, usages_df, save_path='static/device_type_room_usage.png'):
    # 合并 room 和 type 信息
    merged = usages_df.merge(devices_df[['id', 'room', 'type']], left_on='device_id', right_on='id')

    # 按 room + type 分组统计使用次数
    grouped = merged.groupby(['room', 'type']).agg(
        usage_count=('device_id', 'count'),
        total_duration=('duration', 'sum')
    ).reset_index()

    # 可视化：每个房间，每种类型设备的使用次数
    plt.figure(figsize=(12, 6))
    sns.barplot(data=grouped, x='room', y='total_duration', hue='type')
    plt.xlabel('room')
    plt.ylabel('total_duration')
    plt.title('Usage_frequency_distribution')
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.legend(title='device_type')
    plt.savefig(save_path)
    plt.close()

    return save_path