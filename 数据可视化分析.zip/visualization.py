import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def plot_top_energy_consuming_devices(
    usages_df: pd.DataFrame,
    devices_df: pd.DataFrame,
    top_n: int = 10,
    save_path: str = 'static/top_energy_devices.png'
) -> str:
    # 聚合
    total_energy = usages_df.groupby('device_id')['energy_consumption'].sum().reset_index()
    total_energy = total_energy.merge(devices_df, left_on='device_id', right_on='id')

    top_devices = total_energy.sort_values('energy_consumption', ascending=False).head(top_n)

    plt.figure(figsize=(10, 6))
    sns.barplot(
        data=top_devices,
        x='energy_consumption',
        y='name',
        palette='Reds_d'
    )
    plt.xlabel('total_consumption (kWh)')
    plt.ylabel('device_name')
    plt.title(f'Top {top_n} energy_consuming_devices')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    return save_path