from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from utils.load_data import load_json_to_df
from utils.visualization import plot_top_energy_consuming_devices
from utils.visualization_2 import plot_device_type_room_usage
from utils.visualization_3 import plot_user_radar_profiles


app = FastAPI()

'''
@app.get("/analysis/top-energy-devices")
def top_energy_devices(top_n: int = Query(10, ge=1, le=50)):
    usages_df = load_json_to_df("data/device_usages.txt")
    devices_df = load_json_to_df("data/devices.txt")
    img_path = plot_top_energy_consuming_devices(usages_df, devices_df, top_n, save_path=f"static/top_energy_devices.png")
    return FileResponse(img_path, media_type="image/png")
'''

'''
@app.get("/analysis/device-type-room-usage")
def device_type_room_usage():
    usages_df = load_json_to_df("data/device_usages.txt")
    devices_df = load_json_to_df("data/devices.txt")
    img_path = plot_device_type_room_usage(devices_df, usages_df)
    return FileResponse(img_path, media_type="image/png")
'''

'''
@app.get("/analysis/user-risk-radar")
def user_risk_radar():
    users_df = load_json_to_df("data/users.json")
    devices_df = load_json_to_df("data/devices.txt")
    usages_df = load_json_to_df("data/device_usages.txt")
    events_df = load_json_to_df("data/security_events.txt")

    img_risk, img_avg = plot_user_radar_profiles(users_df, devices_df, usages_df, events_df)
    return {
        "risk_users_image": f"/{img_risk}",
        "average_user_image": f"/{img_avg}"
    }
'''

from utils.visualization_house_size_grouped import analyze_house_size_grouped
@app.get("/analysis/house-size-grouped")
def house_size_grouped():
    img_path = analyze_house_size_grouped()
    return FileResponse(img_path, media_type="image/png")