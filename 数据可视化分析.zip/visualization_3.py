import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def plot_user_radar_profiles(users_df, devices_df, usages_df, events_df,
                             save_path_risk='static/risk_users_radar.png',
                             save_path_avg='static/avg_user_radar.png'):

    # 设备信息与用户
    device_user_map = devices_df[['id', 'user_id']].rename(columns={'id': 'device_id'})
    events_df = events_df.merge(device_user_map, on='device_id')
    usages_df = usages_df.merge(device_user_map, on='device_id')

    # 安防事件特征
    user_events = events_df.groupby('user_id').agg(
        total_events=('id', 'count'),
        max_severity=('severity', 'max')
    ).reset_index()

    # 设备数
    device_count = devices_df.groupby('user_id').size().reset_index(name='device_count')

    # 总能耗
    user_energy = usages_df.groupby('user_id')['energy_consumption'].sum().reset_index(name='total_energy')

    # 合并用户画像
    user_profile = users_df[['id', 'house_size']].rename(columns={'id': 'user_id'})
    user_profile = user_profile.merge(device_count, on='user_id', how='left')
    user_profile = user_profile.merge(user_events, on='user_id', how='left')
    user_profile = user_profile.merge(user_energy, on='user_id', how='left')

    # 缺失值填 0
    user_profile.fillna(0, inplace=True)

    # 归一化（MinMax）
    profile_norm = user_profile.copy()
    columns = ['total_events', 'max_severity', 'device_count', 'house_size', 'total_energy']
    for col in columns:
        max_val = profile_norm[col].max()
        min_val = profile_norm[col].min()
        if max_val != min_val:
            profile_norm[col] = (profile_norm[col] - min_val) / (max_val - min_val)
        else:
            profile_norm[col] = 0  # 避免除以 0

    # 高风险用户（按事件数+严重度排序）
    profile_norm['risk_score'] = user_profile['total_events'] * 0.7 + user_profile['max_severity'] * 0.3
    top_users = profile_norm.sort_values('risk_score', ascending=False).head(3)

    # 平均用户
    avg_user = profile_norm[columns].mean().values

    def draw_radar(data_list, labels, user_names, save_path, title):
        N = len(labels)
        angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
        angles += angles[:1]

        fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
        for idx, data in enumerate(data_list):
            values = data.tolist()
            values += values[:1]
            ax.plot(angles, values, label=user_names[idx])
            ax.fill(angles, values, alpha=0.25)

        ax.set_theta_offset(np.pi / 2)
        ax.set_theta_direction(-1)
        ax.set_thetagrids(np.degrees(angles[:-1]), labels)
        ax.set_title(title)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
        plt.tight_layout()
        plt.savefig(save_path)
        plt.close()

    # 图1：Top 3 高风险用户
    data_list = [top_users[col].values for col in columns]
    data_list = np.array(data_list).T
    draw_radar(
        data_list=data_list,
        labels=columns,
        user_names=[f"用户 {uid}" for uid in top_users['user_id']],
        save_path=save_path_risk,
        title="高风险用户画像"
    )

    # 图2：平均用户画像
    draw_radar(
        data_list=[avg_user],
        labels=columns,
        user_names=["平均用户"],
        save_path=save_path_avg,
        title="平均用户画像"
    )

    return save_path_risk, save_path_avg